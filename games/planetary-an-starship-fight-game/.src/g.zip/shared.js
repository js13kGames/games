let{random:rnd,round,sqrt,abs,sign,sin,cos,PI}=Math,PI2=2*PI,mkID=()=>rnd().toString(36).split(".")[1],upDalay=200,log=console.log;
