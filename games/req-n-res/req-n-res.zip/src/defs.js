//const FIELD_W = 15;
//const FIELD_W = 25;
const FIELD_H = 15;

const CELL_SIZE = 5;

const PLAYER_W = CELL_SIZE;
const PLAYER_H = CELL_SIZE;

const ENEMY_W = CELL_SIZE;
const ENEMY_H = CELL_SIZE;

const SCREEN_W = 300;
const SCREEN_H = 225;

//const MAP_X = SCREEN_W - FIELD_W * CELL_SIZE;
const MAP_Y = SCREEN_H - FIELD_H * CELL_SIZE;

//const TIME_LIMIT = 404;
const TIME_LIMIT = 404;

const CONTENTS = ['goal', 'key', 'map'];

const FONT_SIZE = 15;

const NUM_OF_STAGE = 3;
