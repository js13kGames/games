function Player (x, y) {
  this.x = x || 0;
  this.y = y || 0;
  this.velocityX = 0;
  this.velocityY = 0;
  this.hp = 30;
}
