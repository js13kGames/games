var ĉuprotokoli = false;
var helponivelo = 0;
var frazoj = [
    [
        [
            "👾🤌"
        ],
        [
            "|=0",
            "hGh",
            "]|E_",
            "yRUb^b"
        ],
        [
            "X\u001d",
            "{g",
            "OT{XO}^"
        ]
    ],
    [
        [
            "👽💤"
        ],
        [
            "|=0",
            "]LWuaw",
            "I_R",
            "Hpbuu"
        ]
    ],
    [
        [
            "👾👰"
        ],
        [
            "|=",
            "aSRh",
            "YvzW",
            "Xm",
            "SyDp^"
        ],
        [
            "mu6",
            "Nfr",
            "C`pX",
            "J}Y",
            "=]kW"
        ]
    ],
    [
        [
            "👾👣🎙"
        ],
        [
            "HR1",
            "T_g",
            "tzN",
            "Xm0",
            "KsYo",
            "]Cxr"
        ]
    ],
    [
        [
            "👼🎽"
        ],
        [
            "|=",
            "\\`?X",
            "c~E_"
        ]
    ],
    [
        [
            "👿👋"
        ],
        [
            "|=0",
            [
                "hGh|fx",
                "Iĉu_"
            ],
            "Rpbuuj",
            "IwmP"
        ]
    ],
    [
        [
            "🙐🚥🍮"
        ],
        [
            "HR1",
            "IWg",
            "w~",
            "QMzĎuU",
            "mQ@",
            "XLtl"
        ],
        [
            "~!",
            "^pY",
            "O",
            "X<fŃ]\\",
            [
                "J|Lþ<M",
                "]|sĂ"
            ],
            "gYK~"
        ]
    ],
    [
        [
            "🐯🥺"
        ],
        [
            "|=0",
            "bMbg",
            "vzRĉmd",
            "C@",
            "[suYMs"
        ]
    ],
    [
        [
            "👽👑"
        ],
        [
            "|=0",
            "]LWuaw",
            "T[~euU",
            "c\\vue\u001d",
            "wmP"
        ]
    ],
    [
        [
            "👼👏"
        ],
        [
            "|=0",
            "]LWug",
            "yV`md",
            [
                "h\u000fĊUn}qMs",
                "ćKm~S"
            ]
        ]
    ],
    [
        [
            "🐸🍍"
        ],
        [
            "|=0",
            "fCimm",
            "QMzĎuU",
            "mQ@",
            "zi?lm"
        ]
    ],
    [
        [
            "🐾🚥🍪"
        ],
        [
            "HR1",
            "Ietdx",
            "I",
            "Ym_ıCt",
            "\\bS",
            "iGm"
        ]
    ],
    [
        [
            "👑🍴"
        ],
        [
            "|=0",
            "gPi",
            "l{RWmd",
            "C@",
            "RjyiMs"
        ]
    ],
    [
        [
            "🌴🌕"
        ],
        [
            "|=",
            "dgLe",
            "~Ys",
            "E",
            "X_"
        ],
        [
            "Uv^p",
            "XH",
            "qs"
        ]
    ],
    [
        [
            "🐝🍈"
        ],
        [
            "|=0",
            "]Sd|cu",
            "QMzĎuU",
            "mQ@",
            "fKtl"
        ]
    ],
    [
        [
            "🐚🚥🍆"
        ],
        [
            "HR1",
            [
                "@eg",
                "kZUz`"
            ],
            "G",
            "nQoıXQ",
            "q__",
            "CcNFZI"
        ],
        [
            "d;",
            [
                "K_y",
                "EPQCe"
            ],
            "o",
            "Rv|ĔYP",
            "zwxZfw"
        ],
        [
            [
                "cR}",
                "taG"
            ],
            "hu",
            "IR`ûW",
            "cjWUwVQk^"
        ]
    ],
    [
        [
            "🐦👙"
        ],
        [
            "|=0",
            "]?fg",
            "vzRĉmd",
            "C@",
            "ōve"
        ],
        [
            "Jf=",
            "~Re~",
            "ROĹLN",
            "ŕkS"
        ]
    ],
    [
        [
            "👒🚥🍶"
        ],
        [
            "HR1",
            "NW\\x",
            "I",
            "Ym_ıCt",
            "\\bS",
            "^Jfa~ėb}"
        ],
        [
            "UOZE",
            "f",
            "iJĆkV",
            "HG;ZzĿT"
        ]
    ],
    [
        [
            "👾🎞"
        ],
        [
            "|=0",
            "hGh",
            "cjXM",
            "ayT",
            "nYlfDtl"
        ],
        [
            "C2",
            "NP",
            "LIlo",
            "N",
            "VsNSJ@fx"
        ],
        [
            "QvM",
            "maO~",
            "hPt"
        ]
    ],
    [
        [
            "🌽"
        ],
        [
            "j|QgSQ"
        ],
        [
            "bt7",
            "yYb{",
            "WuNbc"
        ],
        [
            "mu6",
            "Nqs",
            "HT{F",
            "E",
            "W<7",
            [
                "qK",
                "òsHMJ"
            ]
        ]
    ],
    [
        [
            "🐳🌶"
        ],
        [
            "|=0",
            "S@[g",
            "ŦzXM",
            "]u!",
            "g\\pfL"
        ],
        [
            "f`Q]",
            "ŬFB",
            "QGgkS"
        ],
        [
            "Uk\"",
            "B=?c",
            "|NyXk",
            "At",
            "hU",
            "u[pw"
        ],
        [
            "vfM",
            "[I",
            "z_",
            "vH`dM`"
        ]
    ],
    [
        [
            "🦘🐖"
        ],
        [
            "|=0",
            "eIehr",
            "OMv",
            "]u!",
            "g_s`It",
            "`C_pX"
        ],
        [
            "BLGY",
            "hJZ",
            "\\uRSKCf",
            "zt",
            "QvM",
            "]gO|r"
        ]
    ],
    [
        [
            "💘🏪"
        ],
        [
            "|=0",
            "Y?hwa|S",
            "XmSTbc",
            "Ċy",
            "c?D",
            "iVX{T"
        ],
        [
            "B[",
            "R<je\\X",
            "qDS?;j",
            "zI",
            "Pvk]I~"
        ]
    ],
    [
        [
            "👼🏀"
        ],
        [
            "|=0",
            "]LWug",
            [
                "pzNZud",
                "{Ck^b"
            ],
            "c?D",
            "nC_~S"
        ]
    ],
    [
        [
            "👾❞☾"
        ],
        [
            "HR1",
            "T_g",
            "jE_",
            "|RwQo"
        ]
    ],
    [
        [
            "👽🙉⛺"
        ],
        [
            "HR1",
            "IdtZrS",
            "\\~VıCt",
            "Uo",
            "X\u001d",
            [
                "upĺG]~",
                "PSZ"
            ]
        ]
    ],
    [
        [
            "👿🌷🐨"
        ],
        [
            "HR1",
            "T_aw",
            "H[zR",
            "ObY{e",
            "?q",
            "j\\",
            "G_tKOZ"
        ],
        [
            "GYe",
            "rRRxR",
            "N<HĔkX",
            "o6",
            "]Ith^o",
            "m",
            "bR"
        ],
        [
            "s1",
            "Gi",
            "}=_ďG]tk",
            "vzMf{_",
            "uN",
            "mQ@",
            "ycCk_Q"
        ]
    ],
    [
        [
            "🛿🙻"
        ],
        [
            "qRZSB_g",
            "tzN",
            "Tq]}Mp`uyiM",
            "kjCfN"
        ],
        [
            "JU}^",
            "<n]MUy",
            "NBE",
            "B\\uT\\jL"
        ],
        [
            "t{w",
            "[b",
            "~~ue|R",
            "~s\\",
            "?",
            "c{KafCh"
        ],
        [
            "dj",
            "zZUmU}Np",
            "[b~",
            "c?",
            "mcMbYS",
            "QGm]\\"
        ],
        [
            "|_sDEDFf",
            "kO",
            "}scaH~{{^k",
            "t{b"
        ]
    ],
    [
        [
            "👋💣"
        ],
        [
            "|=0",
            "eGc|g",
            "ľ~XM",
            "WyMbĥp"
        ],
        [
            "c?D",
            "qKb",
            "uJB"
        ]
    ],
    [
        [
            "🐃🚜"
        ],
        [
            "|=0",
            "X?Xat",
            "T^{UMuQt",
            [
                "ű`Nth",
                "QTTO"
            ]
        ],
        [
            "L\u001a",
            "^^[Ty",
            "SSJ>lsX",
            [
                "ŲwggK",
                "qh~]"
            ]
        ],
        [
            "g~j}l",
            "tH",
            [
                "Ű{bH",
                "wnF"
            ]
        ]
    ],
    [
        [
            "🐟🔟"
        ],
        [
            "|=0",
            "VPW~g",
            [
                "nW\\ucuU",
                "lbbĝXQ"
            ],
            "k_Qa"
        ],
        [
            "sWLU",
            [
                "@dlRJ}",
                "NS<ãX"
            ],
            "kO}e"
        ]
    ]
];

var ĉifrilo = [
    22, -6, 16, -36, -15, -14, -34, -10, 19, -8,
    9, 25, -28, -20, 12, -15, 20, -30, 1, -16,
    1, 20, -9, -34, 5, -2, 32, 29, -30, -13,
    15, -27, 38, -31, 28, -21, -37, -8, 38, -4,
    -23, 27, -23, 10, -29, -31, -37, -38, -9, 27,
    25, 10, -27, 21, 14, -9, -8, -35, 15, 35,
    7, 22, 15, -17, 1, 29, 8, 31, 20, 1,
    34, 16, -29, 19, 18, -14, 27, -34, 32, 31
];
var ĉifriloPozicio = 0;

function transformi(objekto, ĉifri)
{
    var anstataŭo;
    if (objekto instanceof Array) {
        anstataŭo = [];
        for (var i in objekto) {
            anstataŭo[i] = transformi(objekto[i], ĉifri);
        }
        return anstataŭo;
    }

    var punkto, deŝovo;
    anstataŭo = '';
    protokoli(objekto, 'Transformata');
    for (var i = 0; i < objekto.length; ++i) {
        punkto = objekto.codePointAt(i);
        deŝovo = ĉifrilo[ĉifriloPozicio];
        ĉifriloPozicio = (ĉifriloPozicio + 1) % ĉifrilo.length;

        if (punkto > 65535) {
            i += 1;
        }

        if (!ĉifri) {
            deŝovo = -deŝovo;
        }

        protokoli([punkto, deŝovo], String.fromCodePoint(punkto));

        anstataŭo += String.fromCodePoint(punkto + deŝovo);
    }
    return anstataŭo;
}

function encrypt(objekto)
{
    ĉifriloPozicio = 0;
    return transformi(objekto, true);
}

function malĉifri(objekto)
{
    ĉifriloPozicio = 0;
    return transformi(objekto, false);
}

var elekteblajFrazoj = [];
var indekso = -1;
var frazo;
var lastaKlavo = '';
var lastaLoko = -1;

function hazardigi(aro)
{
    var j, x, i;
    for (i = aro.length - 1; i > 0; --i) {
        j = Math.floor(Math.random() * (i + 1));
        x = aro[i];
        aro[i] = aro[j];
        aro[j] = x;
    }
    return aro;
}

function xSistemigi(elemento, okazo)
{
    const ĉapelebloj = 'CcGgHhJjSs';

    var komenco = elemento.selectionStart;
    var fino = elemento.selectionEnd;

    var klavo = okazo.key;

    if (klavo == 'Enter') {
        kontroliRespondon();
        return false;
    }

    if ((klavo != 'x' && klavo != 'X') || komenco != fino || ĉapelebloj.indexOf(lastaKlavo) == -1) {
        lastaKlavo = klavo;
        lastaLoko = fino;
        return;
    }

    var antaŭa = elemento.value.substring(0, komenco);
    var posta = elemento.value.substring(fino);
    var mappings = {
        'c': 'ĉ',
        'C': 'Ĉ',
        'g': 'ĝ',
        'G': 'Ĝ',
        'h': 'ĥ',
        'H': 'Ĥ',
        'j': 'ĵ',
        'J': 'Ĵ',
        's': 'ŝ',
        'S': 'Ŝ',
    };

    if (typeof mappings[lastaKlavo] != 'undefined') {
        var nova = mappings[lastaKlavo];
        elemento.value = antaŭa.substr(0, antaŭa.length - 1) + nova + posta;
    }

    lastaKlavo = klavo;
    lastaLoko = elemento.selectionEnd;

    return false;
}

function komenci()
{
    elekteblajFrazoj = [];
    for (var i in frazoj) {
        elekteblajFrazoj.push(Number(i));
    }
    akiriBildon();
    nevidebligi($('finita'));
    videbligi($('ludo'));
    videbligi($('teksto-respondo'));
}

function protokoli(mesaĝo, speco)
{
    if (!ĉuprotokoli) {
        return;
    }
    if (speco) {
        console.log(mesaĝo, speco);
    } else {
        console.log(mesaĝo);
    }
}

function $(id)
{
    return document.getElementById(id);
}

function nova(nomo)
{
    return document.createElement(nomo);
}

function videbligi(nodo)
{
    nodo.className = nodo.className.replace(/\s*nevidebla\s*/, ' ').trim();
}

function nevidebligi(nodo)
{
    if (nodo.className.indexOf('nevidebla') == -1) {
        nodo.className += ' nevidebla';
    }
}

function akiriBildon()
{
    indekso = elekteblajFrazoj[Math.floor(Math.random() * elekteblajFrazoj.length)];
    frazo = malĉifri(frazoj[indekso]);

    protokoli(frazo[1], 'Elektita frazo');
    protokoli(indekso, 'Elektita indekso');

    $('bildo').textContent = frazo[0];
    $('poentaro').textContent = (frazoj.length - elekteblajFrazoj.length) + '/' +  frazoj.length;
}

function kontroliKongruon(vorto1, vorto2)
{
    if (dezirata_vorto instanceof Array) {
        for (var i in vorto2) {
            if (vorto1.localeCompare(vorto2[i], 'eo', {'sensitivity': 'accent'}) == 0) {
                return true;
            }
        }
        return false;
    }
    return (vorto1.localeCompare(vorto2, 'eo', {'sensitivity': 'accent'}) == 0);
}

function kontroliRespondon()
{
    var enmeto = $('teksto-respondo-enmetejo').value.trim();
    var vortoj = enmeto.split(/\s+/);
    var frazopcio, dezirataj, atingitaj, i, j, deva, egalaj, estasSignoĉeno;
    var kontroliBlatojn = true;

    nevidebligi($('superteksto-jes'));
    nevidebligi($('superteksto-ne'));

    for (var i = 1; i < frazo.length; ++i) {
        dezirataj = frazo[i].length;
        atingitaj = 0;
        protokoli(frazo[i].join(' '));

        frazopcio = frazo[i];
        pozicio = 0;
        for (j in frazopcio) {
            dezirata_vorto = frazopcio[j];

            protokoli(j + ', ' + pozicio + ': ' + dezirata_vorto, "Vorto");

            deva = true;
            estasSignoĉeno = (typeof dezirata_vorto === 'string');
            if (estasSignoĉeno && dezirata_vorto.charAt(dezirata_vorto.length - 1) == '?') {
                deva = false;
                dezirata_vorto = dezirata_vorto.substring(0, dezirata_vorto.length - 1);
            }
            protokoli(deva, 'deva');
            protokoli(estasSignoĉeno, 'estas signoĉeno');
            if (estasSignoĉeno) {
                protokoli(dezirata_vorto.charAt(dezirata_vorto.length - 1), 'lastChar');
            }

            if (typeof vortoj[pozicio] === 'undefined') {
                protokoli("Enmetita frazo jam finiĝis");
                if (!deva) {
                    protokoli(!deva, 'nedeva');
                    dezirataj--;
                }
                break;
            }

            egalaj = kontroliKongruon(vortoj[pozicio], dezirata_vorto);
            protokoli([dezirata_vorto, vortoj[pozicio]], 'komparas')

            if (egalaj) {
                protokoli(egalaj, 'egalaj');
                ++atingitaj;
                ++pozicio;
            } else if (!deva) {
                protokoli(!deva, 'nedeva');
                dezirataj--;
            } else {
                protokoli(dezirata_vorto + ' kaj ' + vortoj[pozicio], 'ne egalaj');
                break;
            }
        }
        protokoli([dezirataj, atingitaj], 'dezirataj k atingitaj');
        protokoli([pozicio, vortoj.length], 'pozicio k longeco');
        if (dezirataj == atingitaj && pozicio == vortoj.length) {
            montriSupertekston('jes');
            return;
        }
    }
    protokoli('ne taŭgas');
    montriSupertekston('ne');
}

function montriSupertekston(speco)
{
    var ejo = $('superteksto-' + speco);
    videbligi(ejo);
    if (speco == 'jes') {
        $('bing').play();
    } else {
        $('barp').play();
    }
    window.setTimeout(function() {
        nevidebligi(ejo);
        if (speco == 'jes') {
            $('teksto-respondo-enmetejo').value = '';
            sekve();
        }
    }, 750);
}

function sekve()
{
    // Forigu la bildon de la listo, kaj elektu novan bildon.
    // Se ne plu ekzistas bildoj, la ludo finiĝas
    if (indekso > -1) {
        protokoli(indekso, 'Forigi elementon');

        helponivelo = 0;
        forviŝiElektojn();

        var forigenda = elekteblajFrazoj.indexOf(indekso);
        if (forigenda > -1) {
            elekteblajFrazoj.splice(forigenda, 1);
            if (elekteblajFrazoj.length == 0) {
                $('hooray').play();
                protokoli('FINITE');
                nevidebligi($('ludo'));
                videbligi($('finita'));
                return;
            }
        } else {
            protokoli('Ne trovis forigendan indekson' + indekso, 'Eraro');
        }

        protokoli(frazoj, 'Frazoj restantaj');

        akiriBildon();
        videbligi($('teksto-respondo'));
        videbligi($('helpi'));
    }
}

function helpi()
{
    switch (helponivelo) {
    case 0:
        ++helponivelo;
        montriElektojn();
        break;
    case 1:
        ++helponivelo;
        kaŝiElektojn();
        nevidebligi($('helpi'));
        break;
    }
}


/**
 * Aranĝi la unuan elekton, por komparo
 */
function unuaElekto()
{
    var elektoj = [], elekto;
    for (i in frazo[1]) {
        if (typeof frazo[1][i] == 'string') {
            elekto = frazo[1][i];
        } else {
            elekto = frazo[1][i][0];
        }
        elekto = elekto.replace('?', '');
        elektoj.push(elekto);
    }
    return elektoj;
}

function montriElektojn()
{
    // elektu la ĝustajn vortojn, plus aliajn vortojn
    var kvantoDeVortoj = frazo[1].length * 3;
    var i, elekto, partoj, afiksoj, fino;
    var elektoj = unuaElekto();
    var kopioDeVortaro = vortaro.slice();

    while (elektoj.length < kvantoDeVortoj) {
        i = Math.floor(Math.random() * kopioDeVortaro.length);
        elekto = kopioDeVortaro[i];

        partoj = elekto.split(':');
        elekto = partoj[0];

        // hazarde aldonu afikson
        if (partoj.length == 1) {
            fino = elekto.charAt(elekto.length - 1);
            afiksoj = [];
            if (fino == 'i') {
                afiksoj = ['i', 'is', 'is', 'as', 'as', 'os', 'os', 'us', 'u'];
                elekto = elekto.substring(0, elekto.length - 1);
            } else if (fino == 'a' || fino == 'o') {
                afiksoj = ['', '', 'j', 'n', 'jn'];
            }

            if (afiksoj.length > 0) {
                elekto += afiksoj[Math.floor(Math.random() * afiksoj.length)];
            }
        } else if (partoj[1] == 'p') {
            afiksoj = ['', 'n'];
            elekto += afiksoj[Math.floor(Math.random() * afiksoj.length)];
        }
        elektoj.push(elekto);

        kopioDeVortaro.slice(i, 1);
    }

    elektoj = hazardigi(elektoj);

    var elektujo = $('elektoj');
    for (i in elektoj) {
        elekto = kreiElekton(elektoj[i]);
        elektujo.appendChild(elekto);
    }
    nevidebligi($('teksto-respondo'));
    videbligi(elektujo);
}

function kreiElekton(vorto)
{
    var elekto = nova('span');
    elekto.className = 'elekto';
    elekto.textContent = vorto;
    elekto.setAttribute('onclick', 'alklakiVorton(this)');
    return elekto;
}

function kaŝiElektojn()
{
    var elektoj = unuaElekto();
    var kvantoDeVortoj = Math.floor(elektoj.length * 1.75);
    var elektujo = $('elektoj');
    var vortoj = elektujo.getElementsByTagName('span');
    var i, vortoNodo, vorto, malsukcesoj = 0;
    while (vortoj.length > kvantoDeVortoj) {
        i = Math.floor(Math.random() * vortoj.length);
        vortoNodo = vortoj.item(i);
        vorto = vortoNodo.textContent;
        if (elektoj.indexOf(vorto) != -1) {
            if (++malsukcesoj >= 5) {
                break;
            }
            continue;
        }
        malsukcesoj = 0;
        elektujo.removeChild(vortoNodo);
    }
}

function forviŝiElektojn()
{
    var elektujo = $('elektoj');
    var vortoj = elektujo.getElementsByTagName('span');
    var vorto;
    while (vortoj.length > 0) {
        elektujo.removeChild(vortoj.item(0));
    }
    nevidebligi(elektujo);

    elektujo = $('respondejo');
    vortoj = elektujo.getElementsByTagName('span');
    while (vortoj.length > 0) {
        vorto = vortoj.item(0);
        vorto.parentNode.removeChild(vorto);
    }
    nevidebligi(elektujo);
}

function alklakiVorton(nodo)
{
    protokoli(nodo.textContent, 'alklaki');
    nodo.removeAttribute('onclick');
    nodo.onclick = null;
    nodo.className = 'alklakita';
    window.setTimeout(function() {
        var novaNodo;
        protokoli(nodo, 'forviŝiNodon');
        nodo.className = '';
        if (nodo.parentNode.getAttribute('id') == 'elektitaj') {
            novaNodo = $('elektoj').appendChild(nodo);
        } else {
            var butono = $('kontroli-elektitajn');
            novaNodo = butono.parentNode.insertBefore(nodo, butono);
        }
        novaNodo.setAttribute('onclick', 'alklakiVorton(this)');
        videbligi($('respondejo'));

        var teksto = '';
        var vortoj = $('elektitaj').getElementsByTagName('span');
        for (var i = 0; i < vortoj.length; ++i) {
            teksto += ' ' + vortoj.item(i).textContent;
        }
        protokoli(teksto, 'teksto de span-oj');
        $('teksto-respondo-enmetejo').value = teksto;
    }, 200);
}
