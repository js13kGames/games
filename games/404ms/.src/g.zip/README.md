# 404ms

[Ale Cámara](https://twitter.com/soy_yuma)'s entry for the [js13k gamejam 2020](https://js13kgames.com/).

Small game to test how complicated is to make a tiny experience using vanilla HTML+CSS+JS.
Slightly inspired by (but not as cool as) [TEMPRES from tak](https://tak.itch.io/tempres).

Should work on desktop and mobile devices.