function draw() {  
var x = document.getElementById('c').getContext('2d');
     x.fillStyle = "rgb(200,0,0)";
        x.fillRect (10, 10, 55, 50);
}