var NodeType = {
  Start: 0,
  End: 1,
  Connect: 2
};
