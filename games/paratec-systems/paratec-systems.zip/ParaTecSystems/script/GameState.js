var GameState = {

  Starting: 0,
  Paused: 1,
  Playing: 2,
  StartingDay: 3,
  FinishedStage: 4,
  Ended: 5
};
