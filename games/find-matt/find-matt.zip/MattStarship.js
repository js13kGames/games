class MattStarship extends Enemy{constructor(t,e,s,o){super(t,e,s,o,{kind:"matt",color:255,directionColor:85,speed:20,maxDistance:1e3})}}
