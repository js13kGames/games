class StaticMessageBox extends MessageBox{constructor(s,t,e,a={width:8,height:3}){super(s,t,e,a,{static:!0,yOffset:0,distance:20,fontSize:"64px"})}}
