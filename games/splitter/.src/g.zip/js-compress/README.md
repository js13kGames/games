# Splitter-JS

*This game is an entry for js13k games 2017*

## Controls
**Move left**: <-
**Move right**: ->
**Split**: <- + ->

*Refresh to restart*
