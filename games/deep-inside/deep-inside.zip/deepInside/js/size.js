onresize=function(){var e,i,n=innerWidth,t=innerHeight,r=n/t,h=1,o=document.querySelector("#in").style;h>=r?(e=n,i=e/h):(i=t,e=i*h),o.width=e+"px",o.height=i+"px"};
