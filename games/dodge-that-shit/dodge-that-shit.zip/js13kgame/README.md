# Dodge That Shit
This is a game created for the js13kGames 2019 Javascript and HTML5 game development competition. Submissions have to be less than 13kB! Link to competition: https://2019.js13kgames.com/

How to play:
1. Use your arrow keys to dodge shit falling from the ceiling
2. Try not to get hit


Credits:
shit icon - Icon made by https://www.flaticon.com/authors/pixel-perfect

player icon - http://opengameart.org/content/tiny-16-basic by http://opengameart.org/users/sharm

Zenva for the useful video tutorials at https://gamedevacademy.org/js13kgames-tutorial-video-series/
