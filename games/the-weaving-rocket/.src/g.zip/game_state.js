var game_state = "menu";
var frames     = 0;

/**
 * @type { Rocket }
 */
var player = null;

var score      = 0;
var high_score = 0;