q=i=>document.getElementById(i)
copy=a=>a.map(v=>v.slice())
r=n=>Math.random()*n|0
R=a=>a[r(a.length)]
