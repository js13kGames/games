## Parlez13k
A dumb dirty stupid simple messaging app game for [js13k gamejam](http://js13kgames.com/)

 - Keep passing messages until the computer wants to go out with you!
 - You can type anything and click send
 - <13kb file size!


### TODOs
 - Allow user to hit return/enter on keyboard to send message
 - Modify the list items to look more like SMS messages (time, name, ...)
 - Modify scrolling such that we dont have to scroll down to see messages and type
 - Have fun with CSS (lol?)
 - Mobile, VR, Augmented reality, bitcoin, ...
