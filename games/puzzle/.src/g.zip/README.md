HOW TO PLAY
1. Load the index.html file in your web browser

2. Click on the tile you want to move, the tile moves either up,down,left or right depending on the available space.

3. Click on the RESHUFFLE button to get another arrangement of the cat picture.

Enjoy!

*My first entry for JS13k 2025*
