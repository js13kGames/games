function MazeCoordinates(layer, cell) {
    this.layer = layer;
    this.cell = cell;
}