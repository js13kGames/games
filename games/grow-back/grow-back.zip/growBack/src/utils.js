function array2d(w) {
  var arr = []
  for (var i = 0; i < w; i++) {
    arr[i] = []
  }
  return arr
}
