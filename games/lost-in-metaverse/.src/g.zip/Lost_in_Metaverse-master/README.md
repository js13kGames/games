# Lost_in_Metaverse
An submission for @js13kGames A-Frame category. (Js13kGames is a JavaScript coding competition for HTML5 Game Developers. The fun part of the compo is the file size limit set to 13 kilobytes.) 

<a href="https://karanganesan.github.io/Lost_in_Metaverse/index.html">Live Demo</a>
