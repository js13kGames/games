# lost-miner-jsgame
You are a panda miner that tried to be romantic by find a rare gem for your lover.
Sadly you got lost! Try to get out... and in the same time... find a gem for your lover