# desrever
My entry for [js13kGames](http://2015.js13kgames.com/).

Use the Arrow Keys to move around and reach the Goal tile.

## Tiles
* Purple - This is you! The player. 
* Light Blue - This is the floor. You can walk on it.
* Gray - The walls. You can't walk on them.
* Yellow - Swaps the walls with the floors.
* Dark Blue - Switches the arrow keys. 
* Green - Your goal! Get her. 

I made this game for the [js13kGames](http://2015.js13kgames.com/) competition. I need to design more levels but I submitted four levels for the deadline. I learned to work with the HTML5 Canvas and polished up my JavaScript chops. 
