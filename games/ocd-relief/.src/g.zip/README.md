# OCD Relief

Bring moments of relief to folks with OCD (Obsessive-compulsive disorder) through a fun game of organizing messy desktop spaces.

Originally created in couple of hours for participating in [https://js13kgames.com/](https://js13kgames.com/).

# Credits

Game dev: [Sayem Shafayet](https://github.com/ishafayet)

Music: [Mysha Azfar](https://www.linkedin.com/in/myshaazfar)

# License

[MIT](LICENSE)
