"use strict";

const DEFAULT = "DEFAULT";
const FLIPPED = "FLIPPED";
const MATCHED = "MATCHED";

const PLAYER_1 = 0;
const PLAYER_2 = 1;

const EMOJIS = ['🐯', '😺', '🐶', '🐷', '🐸', '🐵'];
