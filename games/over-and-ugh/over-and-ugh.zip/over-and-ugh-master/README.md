# Over And Ugh
Over And Ugh is a small game made in pure HTML, CSS and JS.

In this game you play a secret service supervisor that keeps reporting agents' offline status to look for any suspicious activites.
