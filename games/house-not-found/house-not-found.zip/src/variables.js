let levelBefore = (door = response = 0),
  level = 1;
let dialog = (question = "");
let changeDirection = 'left'
let showDialog = (asked = password = room202 = room401 = room404 = room405 = room501 = dog = keys = screwdriver = money = false);

const doors = [100, 250, 400, 550, 700];
var timer = -1;

var keyRight = (keyUp = keyDown = keyLeft = keyEnter = keyZ = keyEscape = false);

let currentHint = 0;
let dogFrame = 0;
let dogAnimation = 0;
let dogSprite = [dogSprite1, dogSprite2];