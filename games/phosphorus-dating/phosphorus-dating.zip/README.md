**Phosphorus Dating** is a game about Technology and Relationships.

Set in 1996, a lot of people is amazed by Internet and want to try to find someone to date online. **Phosphorus Dating** website has a very smart algorithm to find a match for anybody based on their gender, sexual orientation, age and interests, but for some reason this algorithm is not working as expected.

You are **Cecilia Dent** and have to find the right matches for these people while the algorithm is being fixed.

## How to Play
> You have **5** weeks, until our system is fixed, to match couples based on
> their **gender**, **sexual orientation**, **age** and **interests**. Every week you
> will have to find a good couple for the people in the left list of the
> Phosphorus Dating program. Pick the right person on the right and
> match the couple. If you can't find a good match, you can dismiss
> anybody on the right list, but it uses **Hearts ❤**, which you only get
> when you make a successful couple. You will also need **Hearts ❤** to go
> to the next week.
> 
> When you match a couple, they will go out on a date and you can keep
> up with the progress on the lower left date list on the program. After
> that finishes you'll get a report.

## More Info
This game was created for the #js13k 2016 competition.