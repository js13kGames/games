### Unlucky Blackjack
> :heart: Blackjack implemented in under 13kb.

My entry for [js13kGames 2017](http://2017.js13kgames.com).

Player vs Dealer Blackjack.
You've lost $ 1000. Win it back.

* H to hit.
* S to stand.

You will automatically bet $ 100 every turn.


Clear browser session to reset game.

Source code at:
https://github.com/stpettersens/js13k_2017
