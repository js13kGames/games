'use strict';
module.exports = glitchSquad.server;
