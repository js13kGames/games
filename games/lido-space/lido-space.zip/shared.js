/* eslint-disable */
'use strict'

// @ts-ignore
const ROLE_HOST = 'HOST'
// @ts-ignore
const ROLE_OPPONENT = 'OPPONENT'
// @ts-ignore
const ROLE_SPECTATOR = 'SPECTATOR'
// @ts-ignore
const ROLE_UNKNOWN = null
