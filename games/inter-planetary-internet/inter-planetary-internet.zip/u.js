export function g(s,e){return(Math.floor(Math.random()*(e-s)+1)+s);}
