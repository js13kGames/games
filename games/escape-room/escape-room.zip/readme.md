# Intro
Escape! is a text based game in which you will have to use your wits and a few basic items to free yourself from imprisonment. This game pays homage to the old text based games from years ago. Type commands and then a keyword to proceed through game. Commands used in this game are Look and Use. If you get stuck, hit enter to get the room description again. Also, you can always try:
```
Look Room
```
for initial clues.

Good Luck!


Created by Joseph Ka'ainoa and Robert Rowlands