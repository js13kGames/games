# LOSTindeed
A Javascript game for the js13k competition 2017

The 2017 theme is LOST.
A very few things can describe being lost better than this instance.

Aiming at being a quick disgusting play.
