# Where in Space
The js13k 2021 game by Imagineee: Where in Space?
**When you are stuck in space on a bizarre planet**
# Playing
First you can install the Pokémon font by Super pencil from here: https://github.com/PascalPixel/pokemon-font/blob/v1.8.2/fonts/pokemon-font.ttf (Recommended)

Open open the index.html and get started.

*I didn't have any time for music; so, play some space themed adventure music in the background.*

**NOTE: please zoom if needed to fit in screen due to scaling issues**

## Instructions on playing
Use the WASD keys (or arrow keys), to move around.

Use the Space bar to interact with object.

Click to close information panel.

*no mobile support, I have a plan to release an alternate release with mobile support*
