# Protect-The-Base

A game inspired by Dota's last hitting mechanics.  Don't let your base fall as you get the last hit on creeps and obtain gold.  Utilize your special skill "backtrack" to push the enemy back and give you a tiny bit of breathing room!

arrow keys to move

backspace to use backtrack skill (10 second cooldown)

spacebar to attack the enemy
