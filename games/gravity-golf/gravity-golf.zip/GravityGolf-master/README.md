# GravityGolf

Entry for js13k 2015. It doesn't fit the theme and isn't polished, but I was persuaded to enter it anyway on the promise of a free tshirt. ;) Hopefully it amuses for a few minutes.

When the ball has come to rest, click and hold to aim, release to take a shot.

The aim is to reach the red marker in as few shots as possible. Each level adds a new planet.
