This is my very first game I've ever programmed. I didn't program it myself. 
I got help with the programming of Robert Rüdiger. Thanks for that.
And my friend Claudia Duwe helped me with the design and ideas. Thank you very much. 
The idea was actually that a chicken with a ship stranded.
And lost his memory. Unfortunately, during the course of programming everything turned out differently. 
Now I have landed on a simple jump and run and I'm very stoned on it.
Have fun while playing. 

Press space to begin 
and press c to restart.
good luck
