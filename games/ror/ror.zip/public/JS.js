import Game from './Game.js';
new Game();