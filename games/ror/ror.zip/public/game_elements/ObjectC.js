export default class ObjectC {
    static myGameArea;
}