import {Game} from './Game.js';
import {Vector} from "./Vector.js";

const game = new Game();


window.Vector = Vector;